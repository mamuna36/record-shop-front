
import React from 'react';
import '../../App.css'
import { Link } from 'react-router-dom';
import { Col, Row} from 'react-bootstrap'

function List() {
  const [abgerufen,setAbgerufen] = React.useState(false);
  const [daten,setDaten]         = React.useState(false);
  if ( ! abgerufen )
    fetch('/users/')
    .then( response => response.json() )
    .then( users => {
      setAbgerufen(true);
      setDaten(users);
    })
  return (
    <>
    <Row className='m-2' >
      <Col xs={12} className="d-flex flex-wrap justify-content-center ">
    
      {daten ? (
        daten.map(user => (
          
            <div className='user-custom m-3'>
              <ul className='list-group'>
              <span className='list-group-item list-group-item-dark list-group-item-action list-custom '>KILLER USER</span>
              <li className='list-group-item list-group-item-dark list-group-item-action '>{user.firstName}</li>
              <li className='list-group-item list-group-item-dark list-group-item-action '>{user.lastName} </li>
              <li className='list-group-item list-group-item-dark list-group-item-action '>{user.fullName} </li>
              <li className='list-group-item list-group-item-dark list-group-item-action '>{user.email}    </li>
          </ul>
         
              <Link to={`/admin/users/${user.id}`} className="btn btn-dark btn-block">
                  EDIT
              </Link>
           </div>
      
        ))
      ): null}
       
    </Col>
 </Row>
</>
)}
export default List;
